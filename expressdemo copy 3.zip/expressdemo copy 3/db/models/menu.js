module.exports = class Menu{
    constructor(id, name,url,status){
        this.id= id;
        this.name = name;
        this.url = url;
        this.status = status;
    }
}
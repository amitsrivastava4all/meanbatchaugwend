const UserSchema = require('../models/user');
const encryption = require('../../utils/encrypt');
const userOperations = {
    addUser(userObject){
        const encryptedPwd = encryption.generateHash(userObject.password);
        userObject.password = encryptedPwd;
        return UserSchema.create(userObject);
    
        // UserSchema.create(userObject,(err)=>{
        //     if(err){
        //         console.log("Not Able to add a user");
        //     }
        //     else{
        //         console.log("User Added in DB");
        //     }
        // })
    },
    updateUser(userObject){
        UserSchema.findByIdAndUpdate(userObject.id, {name:'Ram'} ,(err,res)=>{
            if(err){

            }
            else{
                
            }
        })
    },
    deleteUser(userObject){
        UserSchema.findByIdAndDelete(userObject.id, (err,res)=>{
            if(err){

            }
            else{

            }
        })
    },
    findUser(userObject, res){
        const codes = require('../../utils/statuscode');
        UserSchema.findOne(userObject,(err,doc)=>{
            if(err){
                res.status(500).json({'status':codes.FAIL,'message':'Some Issue in DB Side'});
                //console.log('Error During Find ',err);
            }
            else{
                if(doc){
                console.log('Doc is ',doc);
                    const menuHelper= require('./menu');
        const menus = menuHelper.fillMenu();
        const token= require('../../utils/token');
        const tokenId = token.generateToken(userObject.userid);
        res.status(200).json({'status':codes.SUCCESS,'message':'Welcome '+userObject.userid,'menu':menus, token:tokenId});
                }
                else{
                    res.status(200).json({'status':codes.FAIL,'message':'Invalid Userid or Password'});
                }
    }
            
        })
    },
    findUserPromise(userObject){
        const codes = require('../../utils/statuscode');
        const pr = new Promise((resolve, reject)=>{
          
       
            
            UserSchema.findOne({userid:userObject.userid},(err,doc)=>{
                if(err){
                    reject(err);
                   
                }
                else{
                    if(doc){
                        const enc = require('../../utils/encrypt');
                        let result = enc.compareHash(userObject.password,doc.password);
                        if(result){
                            resolve(doc);
                        }
                        else{
                            resolve(null);
                        }
                    }
                    else{
                        resolve(null);
                    }
                    
        }
                
            });
        });
        return pr;
    }
       
}
module.exports = userOperations;
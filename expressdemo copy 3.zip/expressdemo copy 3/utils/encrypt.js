const bcrypt = require('bcrypt');
const encryption = {
    salt : 10,
    generateHash(plainPassword){
            return bcrypt.hashSync(plainPassword,this.salt);
    },
    compareHash(plainPwd, dbPassword){
        return bcrypt.compareSync(plainPwd,dbPassword);
    }
}
module.exports = encryption;
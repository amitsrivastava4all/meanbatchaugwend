module.exports = {
    'SUCCESS':'S',
    'FAIL':'F',
    'ERROR':'E'
};
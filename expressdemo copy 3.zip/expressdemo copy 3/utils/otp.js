const otp = require('otplib');
const secret = 'thisissecret';

 
const token = otp.authenticator.generate("Abcd");
console.log('OTP Number is ',token); 

  const isValid = otp.authenticator.check(token, "Abcd");
   console.log("Valid is "+isValid); 

    const token2 = otp.authenticator.generate("xyz");
console.log('OTP Number is ',token2); 
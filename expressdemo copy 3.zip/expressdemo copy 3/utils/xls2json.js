//const xls2json = require("xls-to-json");
const excelToJson = require("convert-excel-to-json");

const result = excelToJson({
    sourceFile: '/Users/amit/Desktop/questions.xls'
});
console.log("Result is ",result);
// const path = '/Users/amit/Desktop/questions.xls';
// xls2json({
//     input: "questions.xls",  // input xls
//     //output: "output.json", // output json
//     sheet: "sheet1"  // specific sheetname
//     //rowsToSkip: 5 // number of rows to skip at the top of the sheet; defaults to 0
//   }, function(err, result) {
//     if(err) {
//       console.error("Error in XLS Read ",err);
//     } else {
//       console.log("Result of XLS Read is ",result);
//     }
//   });
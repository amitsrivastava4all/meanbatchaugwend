module.exports = {
    secret :'thisismysecret',
    dburl:'mongodb://localhost:27017/myappdb'
}
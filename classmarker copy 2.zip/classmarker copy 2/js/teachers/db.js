const dbOperations = {
    add(questionObject){
        let promise = firebase.database().ref("/questions/"+questionObject.id).set(questionObject);
        return promise;
    },
    getQuestionById(id){
        var stream = firebase.database().ref("/questions/"+id);
        stream.on('value',(snapshot)=>{
            let object = snapshot.val();    
            console.log('Object is ',object);
        })
    }
}






  var firebaseConfig = {
    apiKey: "AIzaSyD9kAY9wMo8DFuObiU--Zk5gd4nnCV0fZ4",
    authDomain: "meanbatch1030.firebaseapp.com",
    databaseURL: "https://meanbatch1030.firebaseio.com",
    projectId: "meanbatch1030",
    storageBucket: "meanbatch1030.appspot.com",
    messagingSenderId: "119975199553",
    appId: "1:119975199553:web:490b8fbecefe1f6c01d7c0"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
